#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_SERIAL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT_DIR="$(cd "$LIB_SERIAL_DIR/../.." && pwd)"
BUILD_DIR="$LIB_SERIAL_DIR/build"
BINARY_PATH="$BUILD_DIR/serial_service"
INSTALL_BIN="/usr/local/bin/serial_service"
INSTALL_CONFIG_DIR="/etc/doly"
INSTALL_CONFIG="$INSTALL_CONFIG_DIR/serial.yaml"
UNIT_FILE="/etc/systemd/system/doly-serial.service"

# default to running as user 'pi' in group 'dialout' (change if needed)
RUN_AS_USER=${RUN_AS_USER:-pi}
RUN_AS_GROUP=${RUN_AS_GROUP:-dialout}

echo "Using build dir: $BUILD_DIR"

if [ ! -x "$BINARY_PATH" ]; then
    echo "Binary not found: $BINARY_PATH; building..."
    if ! command -v cmake >/dev/null 2>&1; then
        echo "cmake not found. Please install cmake or build the project manually." >&2
        exit 1
    fi
    mkdir -p "$BUILD_DIR"
    cmake -S "$LIB_SERIAL_DIR" -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release
    cmake --build "$BUILD_DIR" -j$(nproc 2>/dev/null || echo 1)
fi

if [ ! -x "$BINARY_PATH" ]; then
    echo "Binary not built: $BINARY_PATH" >&2
    exit 1
fi

sudo mkdir -p "$INSTALL_CONFIG_DIR"

# Stop service (if running), copy binary and config
sudo systemctl stop doly-serial.service || true
sudo cp "$BINARY_PATH" "$INSTALL_BIN"
sudo chmod +x "$INSTALL_BIN"
SRC_CONFIG="$REPO_ROOT_DIR/config/serial.yaml"
if [ -f "$SRC_CONFIG" ]; then
    sudo cp "$SRC_CONFIG" "$INSTALL_CONFIG"
else
    echo "Warning: config file $SRC_CONFIG not found; skipping copy" >&2
fi

echo "Creating systemd unit: $UNIT_FILE (User=$RUN_AS_USER Group=$RUN_AS_GROUP)"
sudo tee "$UNIT_FILE" >/dev/null <<EOF
[Unit]
Description=Doly Serial Service
After=network.target

[Service]
Type=simple
ExecStart=$INSTALL_BIN --config $INSTALL_CONFIG
User=$RUN_AS_USER
Group=$RUN_AS_GROUP
ExecStartPost=/bin/sh -c 'sleep 0.1; if [ -e /tmp/doly_zmq.sock ]; then chmod 0666 /tmp/doly_zmq.sock || true; fi'
Restart=on-failure
RestartSec=2
PIDFile=/var/run/doly-serial.pid

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable doly-serial.service
sudo systemctl restart doly-serial.service
sudo systemctl status --no-pager doly-serial.service

echo "Installed and started doly-serial.service"
#!/usr/bin/env bash
# Installs serial_service binary and systemd unit for running the service
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_SERIAL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT_DIR="$(cd "$LIB_SERIAL_DIR/../.." && pwd)"
BUILD_DIR="$LIB_SERIAL_DIR/build"
BINARY_PATH="$BUILD_DIR/serial_service"
INSTALL_BIN="/usr/local/bin/serial_service"
INSTALL_CONFIG_DIR="/etc/doly"
INSTALL_CONFIG="$INSTALL_CONFIG_DIR/serial.yaml"
UNIT_FILE="/etc/systemd/system/doly-serial.service"
RUN_AS_USER=${RUN_AS_USER:-pi}
RUN_AS_GROUP=${RUN_AS_GROUP:-dialout}

if [ ! -x "$BINARY_PATH" ]; then
    echo "Binary not found: $BINARY_PATH" >&2
    echo "Attempting to build serial_service..."
    # Ensure cmake is present
    if ! command -v cmake >/dev/null 2>&1; then
        echo "cmake not found. Please install cmake or build the project manually." >&2
        exit 1
    fi
    mkdir -p "$BUILD_DIR"
    if ! cmake -S "$LIB_SERIAL_DIR" -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release; then
        echo "cmake configure failed" >&2
        exit 1
    fi
    if ! cmake --build "$BUILD_DIR" -j$(nproc 2>/dev/null || echo 1); then
        echo "build failed" >&2
        exit 1
    fi
    if [ ! -x "$BINARY_PATH" ]; then
        echo "Binary still not found after build: $BINARY_PATH" >&2
        exit 1
    fi
    echo "Build completed: $BINARY_PATH"
fi

sudo mkdir -p "$INSTALL_CONFIG_DIR"

# Stop service if running to avoid copying over a running binary
sudo systemctl stop doly-serial.service || true
sudo cp "$BINARY_PATH" "$INSTALL_BIN"
sudo chmod +x "$INSTALL_BIN"
SRC_CONFIG="$REPO_ROOT_DIR/config/serial.yaml"
if [ -f "$SRC_CONFIG" ]; then
    sudo cp "$SRC_CONFIG" "$INSTALL_CONFIG"
else
    echo "Warning: config file $SRC_CONFIG not found; creating default config from binary defaults" >&2
    fi
    
    # Removed stray EOF line
EOF

cat <<EOF | sudo tee "$UNIT_FILE" >/dev/null
[Unit]
Description=Doly Serial Service
After=network.target

[Service]
Type=simple
ExecStart=$INSTALL_BIN --config $INSTALL_CONFIG
User=$RUN_AS_USER
Group=$RUN_AS_GROUP
# Ensure IPC socket file is world-writable so non-root clients can connect
ExecStartPost=/bin/sh -c 'sleep 0.1; if [ -e /tmp/doly_zmq.sock ]; then chmod 0666 /tmp/doly_zmq.sock || true; fi'
Restart=on-failure
RestartSec=2
PIDFile=/var/run/doly-serial.pid

[Install]
WantedBy=multi-user.target
EOF
     # Removed stray EOF line
     # EOF
     cat <<EOF | sudo tee "$UNIT_FILE" >/dev/null
sudo systemctl daemon-reload
sudo systemctl enable doly-serial.service
sudo systemctl restart doly-serial.service
sudo systemctl status --no-pager doly-serial.service

echo "Installed and started doly-serial.service"
