file(REMOVE_RECURSE
  "CMakeFiles/SerialControl.dir/src/serial_service.cpp.o"
  "CMakeFiles/SerialControl.dir/src/serial_service.cpp.o.d"
  "libSerialControl.pdb"
  "libSerialControl.so"
  "libSerialControl.so.1"
  "libSerialControl.so.1.0.0"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/SerialControl.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
