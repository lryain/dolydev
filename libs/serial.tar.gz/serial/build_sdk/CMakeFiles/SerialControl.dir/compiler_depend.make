# Empty compiler generated dependencies file for SerialControl.
# This may be replaced when dependencies are built.
