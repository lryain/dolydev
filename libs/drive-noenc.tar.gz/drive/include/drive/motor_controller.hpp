#ifndef MOTOR_CONTROLLER_HPP
#define MOTOR_CONTROLLER_HPP

#include <iostream>
#include <thread>
#include <mutex>
#include <atomic>
#include <chrono>
#include <functional>
#include <linux/i2c-dev.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <fstream>
#include <sstream>
#include <string>
#include "pid_controller.hpp"
#include "encoder_reader.hpp"
#include "safety_monitor.hpp"

class MotorController {
private:
    // PID 位置控制结构体
    struct PositionPIDConfig {
        float kp;           // 比例增益
        float ki;           // 积分增益
        float kd;           // 微分增益
        float ki_limit;     // 积分限制
        float output_min;   // 输出最小值（%）
        float output_max;   // 输出最大值（%）
        uint32_t control_period_ms;  // 控制周期（毫秒）
    };

    // PID 状态结构体
    struct PIDState {
        float integral;          // 积分累积值
        int32_t last_error;      // 上次误差
        uint32_t last_time_us;   // 上次更新时间（微秒）
        
        void reset() {
            integral = 0.0f;
            last_error = 0;
            last_time_us = 0;
        }
    };

    // 编码器配置结构体（前置声明）
    struct EncoderConfig {
        int pulses_per_revolution;      // 脉冲/圈（12）
        float wheel_diameter_cm;        // 轮直径（3.0 cm）
        float wheel_circumference_cm;   // 轮周长（9.4248 cm）
        float cm_per_pulse;             // 每脉冲距离（0.7854 cm）
        float axle_width_cm;            // 轮距（10.5 cm）
        float turn_compensation_factor; // 转向补偿因子（1.0）
        int position_tolerance;         // 位置误差容限（脉冲数）
        float angle_tolerance_deg;      // 角度误差容限（度数）
        // 目前和doly_drive又冲突，暂时默认禁用
        bool enable_encoder;            // 是否启用编码器（默认false）
        // M2 调试参数
        bool enable_pid;                // 是否启用 PID 控制（默认false）
        bool debug_encoder;             // 是否输出详细编码器日志
        bool debug_pulses;              // 是否输出脉冲计算日志
        
        // M2 死区参数
        float pwm_deadzone;             // PWM 死区下限（默认 0.1）
        float pwm_min_active;           // 最小有效 PWM（默认 0.1）
        float pwm_max;                  // 最大 PWM 值（默认 1.0）
    };

    int i2c_fd;
    std::string device_path;
    int pca9685_addr;
    std::atomic<bool> continuous_mode;
    std::atomic<float> auto_stop_timeout;
    std::thread auto_stop_thread;
    std::atomic<bool> auto_stop_cancel;  // 用于取消定时器
    std::mutex motor_mutex;
    std::atomic<bool> running;

    // 电机速度状态
    float left_speed;
    float right_speed;

    // 缓启动配置（秒）
    float ramp_time_seconds;

    // PWM相关常量
    static constexpr int PWM_FREQUENCY = 100;
    static constexpr int PWM_RESOLUTION = 4096;
    static constexpr int LEFT_IN1_CHANNEL = 12;
    static constexpr int LEFT_IN2_CHANNEL = 13;
    static constexpr int RIGHT_IN1_CHANNEL = 14;
    static constexpr int RIGHT_IN2_CHANNEL = 15;

    // 电机方向配置
    bool left_motor_reverse;
    bool right_motor_reverse;

    // PWM补偿系数（用于补偿不同批次电机的最小PWM值差异）
    // 实际PWM值 = speedToPWM(speed) * pwm_compensation
    float left_pwm_compensation;   // 左电机PWM补偿系数（默认 1.0）
    float right_pwm_compensation;  // 右电机PWM补偿系数（默认 1.0）

    // 平衡补偿系数（编码器误差补偿）
    // 用于补偿左右轮之间的编码器读数差异
    // 实际速度 = 设定速度 * 平衡系数
    float left_scaler = 1.0f;   // 左轮补偿系数（默认 1.0）
    float right_scaler = 1.0f;  // 右轮补偿系数（默认 1.0）

public:
    // PID控制
    PIDController left_pid;
    PIDController right_pid;
    std::atomic<bool> pid_enabled;

    // 编码器反馈（模拟）
    double left_encoder_position;
    double right_encoder_position;

    // 编码器反馈（真实硬件）
    EncoderReader* left_encoder;
    EncoderReader* right_encoder;
    std::atomic<bool> encoders_enabled;
    
    // 编码器偏移量（用于相对位置计算）
    int64_t left_encoder_offset;   // reset_encoders() 时记录的基准值
    int64_t right_encoder_offset;  // reset_encoders() 时记录的基准值
    mutable std::mutex encoder_offset_mutex;  // 保护偏移量的互斥锁

    // 安全监控
    SafetyMonitor* safety_monitor;
    std::atomic<bool> safety_enabled;

    // 电流监测控制
    std::atomic<bool> current_monitoring_enabled;

    // ===== M2 编码器配置 =====
    EncoderConfig encoder_config_;      // 编码器参数配置
    
    // ===== M2 PID 位置控制 =====
    PositionPIDConfig position_pid_config_;  // PID 配置
    PIDState left_pid_state_;           // 左轮 PID 状态
    PIDState right_pid_state_;          // 右轮 PID 状态
    mutable std::mutex pid_state_mutex_; // 保护 PID 状态的互斥锁

public:
    MotorController(const std::string& i2c_dev = "/dev/i2c-3", int addr = 0x40);
    MotorController(const std::string& i2c_dev, int addr, const std::string& config_file);
    ~MotorController();

    // 初始化
    bool init();

    // 基本控制
    void setSpeeds(float left, float right, float duration = -1.0f);
    void stop();
    void brake();  // 紧急刹车：立即停止，跳过缓停逻辑
    void forward(float speed = 0.5f, float duration = -1.0f);
    void backward(float speed = 0.5f, float duration = -1.0f);
    void turnLeft(float speed = 0.5f, float duration = -1.0f);
    void turnRight(float speed = 0.5f, float duration = -1.0f);
    
    // 按脉冲移动控制（基于编码器）
    struct MovePulsesResult {
        bool reached;       // 是否到达目标
        long left_pulses;   // 实际左轮脉冲数
        long right_pulses;  // 实际右轮脉冲数
        double elapsed_time; // 实际耗时（秒）
    };
    MovePulsesResult movePulses(long target_pulses, float throttle = 0.5f, 
                                 double assume_rate = 100.0, double timeout_multiplier = 3.0);
    MovePulsesResult turnPulses(long target_pulses, float throttle = 0.5f, 
                                 bool turn_left = true, double assume_rate = 100.0, double timeout_multiplier = 3.0);

    // ===== M2 新增 API：精确距离与角度控制 =====
    
    /**
     * @brief 按距离移动（前进/后退）
     * @param distance_cm 移动距离（>0 前进，<0 后退）
     * @param throttle 速度系数 [0.0, 1.0]，默认 0.5
     * @param timeout_ms 超时时间（毫秒）
     * @return true 成功，false 失败/超时
     */
    bool move_distance_cm(float distance_cm, float throttle = 0.5f, uint32_t timeout_ms = 5000);

    /**
     * @brief 原地转向（顺/逆时针）
     * @param angle_deg 转向角度（>0 顺时针，<0 逆时针），单位度数
     * @param throttle 速度系数 [0.0, 1.0]，默认 0.5
     * @param timeout_ms 超时时间（毫秒）
     * @return true 成功，false 失败/超时
     */
    bool turn_deg(float angle_deg, float throttle = 0.5f, uint32_t timeout_ms = 5000);

    /**
     * @brief 停止电机并等待停稳
     * @return true 成功
     */
    bool motor_stop_and_wait();

    /**
     * @brief 获取左轮编码器脉冲值
     */
    int32_t get_left_encoder_value() const;

    /**
     * @brief 获取右轮编码器脉冲值
     */
    int32_t get_right_encoder_value() const;

    /**
     * @brief 重置编码器计数器
     */
    void reset_encoders();

    /**
     * @brief 加载编码器配置
     */
    bool load_encoder_config(const std::string& config_file = "motor_config.ini");

    /**
     * @brief 加载PWM补偿值
     */
    void load_pwm_compensation(const std::string& config_file = "motor_config.ini");

    /**
     * @brief 获取编码器配置
     */
    const EncoderConfig& get_encoder_config() const { return encoder_config_; }

    // ===== M2 编码器转换辅助函数 =====
    
    /**
     * @brief 距离（cm）转换为脉冲数
     */
    int32_t distance_to_pulses(float distance_cm) const;

    /**
     * @brief 脉冲数转换为距离（cm）
     */
    float pulses_to_distance(int32_t pulses) const;

    /**
     * @brief 角度转换为脉冲差值（用于原地转向）
     */
    int32_t angle_to_pulse_diff(float angle_deg) const;

    // 模式设置
    void setContinuousMode(bool enabled);
    void setAutoStopTimeout(float timeout);

    // 静态配置方法
    static bool loadMotorConfig(bool& left_reverse, bool& right_reverse, const std::string& config_file = "motor_config.ini", float* ramp_time_out = nullptr);
    bool loadMotorConfig(bool& left_reverse, bool& right_reverse);

    // 获取状态
    float getLeftSpeed() const { return left_speed; }
    float getRightSpeed() const { return right_speed; }
    bool isContinuousMode() const { return continuous_mode; }

    // 获取编码器数据
    long getLeftEncoderPosition() const;
    long getRightEncoderPosition() const;
    long getLeftEncoderDelta();
    long getRightEncoderDelta();

    // PID控制
    void enablePID(bool enabled);
    void setPIDParameters(double kp, double ki, double kd);
    void updateEncoderFeedback(double left_pos, double right_pos);
    bool isPIDEnabled() const { return pid_enabled; }

    // 编码器控制
    void enableEncoders(bool enabled);
    bool initEncoders();
    void updateEncoderFeedbackFromHardware();
    void setEncoderDebugEnabled(bool enabled);
    bool isEncodersEnabled() const { return encoders_enabled; }
    bool hasLeftEncoder() const;
    bool hasRightEncoder() const;

    // 安全监控
    void enableSafetyMonitor(bool enabled);
    void enableSafety(bool enabled);
    bool initSafetyMonitor();
    void safetyCallback(const std::string& message);
    bool isSafe() const;
    bool isSafetyMonitorEnabled() const { return safety_enabled; }

    // 电流监测控制
    void enableCurrentMonitoring(bool enabled);
    bool isCurrentMonitoringEnabled() const { return current_monitoring_enabled; }

    // PCA9685操作 (调试用)
    void setPWM(int channel, int on, int off);
    // Ramp time getter/setter (秒)
    void setRampTime(float seconds) { ramp_time_seconds = seconds; }
    float getRampTime() const { return ramp_time_seconds; }

    // ===== 平衡补偿 (编码器误差补偿) API =====
    /**
     * @brief 设置左右轮PWM补偿系数
     * @param left 左电机PWM补偿系数（默认 1.0）
     * @param right 右电机PWM补偿系数（默认 1.0）
     * 
     * 用于补偿不同批次电机的最小PWM值差异。
     * 实际PWM值 = speedToPWM(speed) * pwm_compensation_coefficient
     * 
     * 使用示例：
     *   setPWMCompensation(0.95, 1.05);  // 左电机PWM降低5%，右电机PWM提高5%
     */
    void setPWMCompensation(float left, float right);

    /**
     * @brief 获取左电机PWM补偿系数
     */
    float getLeftPWMCompensation() const { return left_pwm_compensation; }

    /**
     * @brief 获取右电机PWM补偿系数
     */
    float getRightPWMCompensation() const { return right_pwm_compensation; }

    /**
     * @brief 设置左右轮平衡补偿系数
     * @param left 左轮补偿系数（默认 1.0）
     * @param right 右轮补偿系数（默认 1.0）
     * 
     * 用于补偿左右轮之间的编码器读数差异或传动系统误差。
     * 实际电机速度 = 设定速度 * 对应轮的补偿系数
     * 
     * 使用示例：
     *   setBalanceScalers(0.95, 1.05);  // 左轮减速，右轮加速
     */
    void setBalanceScalers(float left, float right);

    /**
     * @brief 获取左轮补偿系数
     */
    float getLeftScaler() const { return left_scaler; }

    /**
     * @brief 获取右轮补偿系数
     */
    float getRightScaler() const { return right_scaler; }

    /**
     * @brief 设置 PID 位置控制参数
     */
    void setPIDConfig(const PositionPIDConfig& config);
    
    /**
     * @brief 获取 PID 位置控制参数
     */
    const PositionPIDConfig& getPIDConfig() const { return position_pid_config_; }
    
    /**
     * @brief 基于 PID 的精确距离运动（改进版本）
     * @param distance_cm 移动距离（>0 前进，<0 后退）
     * @param max_speed 最大速度系数 [0.0, 1.0]，默认 0.5
     * @param direction 方向 (0=前进, 1=后退)，默认 0
     * @param timeout_ms 超时时间（毫秒）
     * @return true 成功，false 失败/超时
     */
    bool move_distance_cm_pid(float distance_cm, float max_speed = 0.5f, int direction = 0, uint32_t timeout_ms = 5000);
    
    /**
     * @brief 基于 PID 的精确转向（改进版本）
     * @param angle_deg 转向角度（>0 顺时针，<0 逆时针）
     * @param max_speed 最大速度系数 [0.0, 1.0]，默认 0.3
     * @param timeout_ms 超时时间（毫秒）
     * @return true 成功，false 失败/超时
     */
    bool turn_deg_pid(float angle_deg, float max_speed = 0.3f, uint32_t timeout_ms = 5000);

    /**
     * @brief 分阶段速度控制策略（当 enable_pid=false 时使用）
     * 策略：快速加速 -> 巡航 -> 减速 -> 精细爬行
     * @param distance_cm 目标距离（正向前，负向后）
     * @param max_speed 最大速度系数 [0.0, 1.0]
     * @param timeout_ms 超时时间（毫秒）
     * @return true 成功，false 失败/超时
     */
    bool move_distance_cm_with_profile(float distance_cm, float max_speed, uint32_t timeout_ms);

    // ===== 动画系统专用 API（支持加速度、刹车等高级参数） =====
    
    /**
     * @brief 高级距离移动（支持加速度、刹车、方向）
     * 
     * 用于动画系统的 drive_distance block
     * 
     * @param distance_mm 移动距离（毫米）
     * @param speed 速度百分比 [0, 100]
     * @param accel 加速度百分比 [0, 100]，0 表示无加速
     * @param brake 刹车强度百分比 [0, 100]，0 表示无刹车
     * @param direction 方向：0=前进，1=后退
     * @param timeout_ms 超时时间（毫秒）
     * @return true 成功，false 失败/超时
     * 
     * 示例：
     *   drive_distance(1000, 20, 10, 10, 0);  // 前进 100cm，速度 20%，加速 10%，刹车 10%
     */
    bool drive_distance(float distance_mm, int speed, int accel, int brake, int direction, uint32_t timeout_ms = 10000);
    
    /**
     * @brief 高级转向控制（支持两种转向模式）
     * 
     * 用于动画系统的 drive_rotate 和 drive_rotate_left/right blocks
     * 
     * @param angle_deg 转向角度（度）
     * @param speed 速度百分比 [0, 100]
     * @param is_center_turn true=原地转向，false=以一个轮子为中心转向
     * @param timeout_ms 超时时间（毫秒）
     * @return true 成功，false 失败/超时
     * 
     * 示例：
     *   drive_rotate(90, 20, true);   // 原地右转 90°，速度 20%
     *   drive_rotate(-90, 20, false); // 以右轮为中心左转 90°，速度 20%
     */
    bool drive_rotate(float angle_deg, int speed, bool is_center_turn, uint32_t timeout_ms = 8000);
    
    /**
     * @brief 左转（便捷函数）
     */
    bool drive_rotate_left(float angle_deg, int speed, bool is_center_turn, uint32_t timeout_ms = 8000) {
        return drive_rotate(-std::abs(angle_deg), speed, is_center_turn, timeout_ms);
    }
    
    /**
     * @brief 右转（便捷函数）
     */
    bool drive_rotate_right(float angle_deg, int speed, bool is_center_turn, uint32_t timeout_ms = 8000) {
        return drive_rotate(std::abs(angle_deg), speed, is_center_turn, timeout_ms);
    }

    // ===== 动画系统 PID 版本 API =====
    
    /**
     * @brief 基于 PID 的高级距离移动
     * 
     * 用于动画系统的 drive_distance_pid 和 PID 精确控制
     * 
     * @param distance_mm 移动距离（毫米）
     * @param speed 速度百分比 [0, 100]
     * @param accel 加速度百分比 [0, 100]，此版本忽略
     * @param brake 刹车强度百分比 [0, 100]，此版本忽略
     * @param direction 方向：0=前进，1=后退
     * @param timeout_ms 超时时间（毫秒）
     * @return true 成功，false 失败/超时
     */
    bool drive_distance_pid(float distance_mm, int speed, int accel, int brake, int direction, uint32_t timeout_ms = 10000);
    
    /**
     * @brief 基于 PID 的高级转向控制
     * 
     * 用于动画系统的 turn_deg_pid，支持 is_center 参数
     * 
     * @param angle_deg 转向角度（度，正数顺时针，负数逆时针）
     * @param speed 速度百分比 [0, 100]
     * @param is_center_turn true=原地转向，false=以一个轮子为中心转向
     * @param timeout_ms 超时时间（毫秒）
     * @return true 成功，false 失败/超时
     */
    bool turn_deg_pid_advanced(float angle_deg, int speed, bool is_center_turn, uint32_t timeout_ms = 8000);

private:
    /**
     * @brief PID 计算函数（内部使用）
     * @param error 位置误差
     * @param dt 时间差（秒）
     * @param state PID 状态
     * @param config PID 配置
     * @return PWM 输出百分比 [output_min, output_max]
     */
    float calculatePID(int32_t error, float dt, PIDState& state, const PositionPIDConfig& config);

    // PCA9685操作
    bool pca9685Init();
    void setPWMFrequency(int freq);

    // 电机控制
    void applySpeeds();
    void applySpeedsDirect(double left, double right);
    void speedToPWM(float speed, int& in1, int& in2);
    void speedToPWM(float speed, int& in1, int& in2, bool reverse);

    // 自动停止
    void startAutoStopTimer(float duration);
    void cancelAutoStopTimer();
    void autoStopWorker(float duration);
};

#endif // MOTOR_CONTROLLER_HPP
