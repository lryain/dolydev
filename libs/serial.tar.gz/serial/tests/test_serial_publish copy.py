#!/usr/bin/env python3
import sys
import time
import argparse
import zmq


def parse_args():
    p = argparse.ArgumentParser(description='Serial service publish integration test')
    p.add_argument('--topic', type=str, default='event.audio.', help='ZMQ topic prefix to subscribe to (default event.audio.)')
    p.add_argument('--expected', type=int, default=0, help='Number of expected messages (0 means run forever)')
    p.add_argument('--timeout', type=int, default=7, help='Timeout seconds to wait for messages')
    p.add_argument('--no-start', action='store_true', help='If set, do not start serial_service, only subscribe to ZMQ')
    return p.parse_args()



def main():
    args = parse_args()
    topic = args.topic
    expected = args.expected
    timeout = args.timeout

    # Prepare ZMQ subscriber
    ctx = zmq.Context()
    sock = ctx.socket(zmq.SUB)
    # subscribe to the provided topic prefix (default: event.audio.)
    sock.setsockopt(zmq.SUBSCRIBE, topic.encode())
    sock.connect('ipc:///tmp/doly_zmq.sock')
    sock.setsockopt(zmq.RCVTIMEO, 5000)
    print(f"[test] Connected to ipc:///tmp/doly_zmq.sock, subscribing to topic prefix: '{topic}'")
    # Give the socket a small time to connect and complete subscription handshake
    time.sleep(1.0)

    # This script is a pure ZeroMQ subscriber. Start serial_service manually if needed.

    # Try to collect messages
    got = 0
    start = time.time()
    if expected == 0:
        print('[test] Running in watch mode (no expected limit). Press Ctrl+C to exit.')
    try:
        # collect messages
        if expected > 0:
            while got < expected and time.time() - start < timeout:
                try:
                    parts = sock.recv_multipart()
                    topic = parts[0].decode('utf-8', errors='ignore')
                    data = parts[1].decode('utf-8', errors='ignore')
                    print('SUB:', topic, data)
                    got += 1
                except Exception as e:
                    # timeout
                    time.sleep(0.05)
                    continue
        else:
            try:
                while True:
                    try:
                        parts = sock.recv_multipart()
                    except zmq.Again:
                        # no message in RCVTIMEO, continue and wait
                        continue
                    except KeyboardInterrupt:
                        raise
                    except Exception as e:
                        # log and continue
                        print('[test] recv error:', e)
                        time.sleep(0.05)
                        continue
                    topic = parts[0].decode('utf-8', errors='ignore')
                    data = parts[1].decode('utf-8', errors='ignore')
                    print('SUB:', topic, data)
            except KeyboardInterrupt:
                print('\n[test] Stopped by user')
    finally:
        pass

    print(f'Expected {expected} messages, got {got}')
    if got == expected:
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == '__main__':
    main()
