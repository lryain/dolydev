# 串口事件共享内存发布策略分析

## 需求回顾
- 当前 `libs/serial` 通过 ZeroMQ 发布事件；为了让 `xiaozhidev` 这类高频监听模块性能更好，计划新增共享内存的事件发布通道，主要服务于触摸事件（单次打断、双击结束语音）的低延迟感知。
- 现有共享内存结构体统一由 `libs/drive/include/drive/shared_state.hpp` 定义，其他模块直接映射该结构。现在希望评估：是否应继续由 Drive 模块统一定义？还是让每个模块自行定义自己的结构体？

## 方案比较
| 方案 | 优点 | 缺点 |
| --- | --- | --- |
| **统一放在 Drive 模块（当前做法）** | 1. 格式/版本唯一，模块之间共享体积固定；<br>2. 只需维护一份结构，便于 cross-domain 协调；<br>3. Drive 模块已经负责创建共享内存，消费者只需 mmap 即可使用。 | 1. 引入较强的耦合，模块必须依赖 Drive 的头文件；<br>2. 结构扩展后需要全局同步，增加回归成本；<br>3. Drive 角色过重，难以为特定子系统做精细化命名空间；
| **每个模块自行定义结构体** | 1. 逻辑上更清晰，模块内聚；<br>2. 可独立演进议，结构更新无须变动其它模块；<br>3. 减少 Drive 模块的规定性，便于插件化。 | 1. 容易造成内存布局差异（比如版本/对齐/打包方式）；<br>2. 共享区域的版本同步挑战（不同模块必须手动保证头文件一致）；<br>3. 依赖测试变重，其他模块必须自行 mmap + 对齐，容易出错；

## 评估总结
- 共享内存的初衷是跨模块快速通信，**保持一个权威、版本化的结构定义可以避免同步陷阱**。Drive 模块本身已经负责创建与初始化 `/doly_shared_state`，继续承担结构体定义在工程实践上更可靠。
- 但可以在 Drive 的共享结构中**为串口事件留出扩展段**，并在 `libs/serial` 侧提供清晰的封装，避免串口代码上下文里直接依赖庞大的 Drive 头文件。
- 例如：在 `SharedState` 中新增 `struct SerialEvents`（或复用 `Touch` 结构中新增手势标志），Drive 仅声明结构布局，`libs/serial` 提供 `SerialSharedPublisher` 封装、负责原子写入。这样，既保留单一版本，又让串口模块拥有自己的写入逻辑和命名空间。

## 推荐实施方案
1. **结构定义**：在 `SharedState` 中新增一个 `SerialEvent` 子结构，至少包含以下字段（与 `std::atomic`）：
   - 单次触摸触发时间戳 `single_tap_time_ms`
   - 双击触发时间戳 `double_tap_time_ms`
   - 当前触摸状态 `touch_active`（bool）
   - 事件序列号 `sequence`
   由 Drive 模块维护版本号（例如 `SharedState::version`），当字段变更时只需 bump 版本。
2. **串口模块封装**：在 `libs/serial` 内部新增 `SerialSharedPublisher`（或类似类），负责：
   - `shm_open(SHARED_STATE_NAME)` + `mmap`，并校验 `SharedState::magic`。
   - 每当识别出上报事件，使用 `std::atomic::store` 更新对应字段；同时维护一个较小的状态机来避免竞态（单击 vs 双击）。
   - 在写入后 `sequence.fetch_add(1)` 供消费者做更新检测。
3. **文档与契约**：在 `libs/serial/docs/shared_memory_strategy.md`（当前文档）中明确：
   - 哪些事件是共享内存发布的。
   - 消费方如何读取（touch 模块可以直接读取 `SharedState::SerialEvent` 的原子域）。
   - 事件版本与兼容性策略（例如向后兼容字段、版本检测流程）。
4. **测试与部署**：更新 `libs/serial` 的测试程序（比如 `test_wakeword_serial`）以验证共享内存写入；必要时提供一个简单读者脚本模拟 `xiaozhidev` 行为。

## 共享内存写入示意（串口模块视角）
```cpp
// 构造绑定
int fd = shm_open(doly::drive::SHARED_STATE_NAME, O_RDWR, 0660);
void* base = mmap(nullptr, doly::drive::SHARED_STATE_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
auto* shared = reinterpret_cast<doly::drive::SharedState*>(base);
if (shared->magic != 0xD014FEED) {
    // ... 兼容性处理
}

// 写入事件
shared->serial_event.touch_active.store(true, std::memory_order_relaxed);
shared->serial_event.single_tap_time_ms.store(now_ms(), std::memory_order_relaxed);
shared->serial_event.sequence.fetch_add(1, std::memory_order_release);
```
*上述示例中的 `SerialEvent` 由 Drive 统一声明，串口模块只负责写入。*

## 结语与建议
- 保持 Drive 里的共享结构作为唯一版本是最安全的做法；同时在 `libs/serial` 内形成自己的写入封装，避免其他模块直接 `#include` 整个 `shared_state.hpp`。
- 后续若有更多独立组件需要共享内存，可以考虑在 `libs/drive/include/drive` 下再拆分 `shared_state_serial.hpp`、`shared_state_touch.hpp` 等子文件，但仍由 Drive 统一汇总并出口。
- 与 `xiaozhidev` 的集成时，先确认消费流程（是否使用 `sequence` 或 `magic`）再触发部署脚本；保护写入可见性并做好版本升级通知。
