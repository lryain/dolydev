#!/usr/bin/env bash
# Redeploy a new built serial_service binary and restart systemd service
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIB_SERIAL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
BUILD_DIR="$LIB_SERIAL_DIR/build"
BINARY_PATH="$BUILD_DIR/serial_service"
INSTALL_BIN="/usr/local/bin/serial_service"
UNIT_NAME="doly-serial.service"

echo "Building serial_service (release) in $BUILD_DIR..."
if ! command -v cmake >/dev/null 2>&1; then
    echo "cmake not found. Please install cmake or build the project manually." >&2
    exit 1
fi
mkdir -p "$BUILD_DIR"
if ! cmake -S "$LIB_SERIAL_DIR" -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release; then
    echo "cmake configure failed" >&2
    exit 1
fi
if ! cmake --build "$BUILD_DIR" -j$(nproc 2>/dev/null || echo 1); then
    echo "build failed" >&2
    exit 1
fi
if [ ! -x "$BINARY_PATH" ]; then
    echo "Binary still not found after build: $BINARY_PATH" >&2
    exit 1
fi

sudo systemctl stop $UNIT_NAME || true
sudo cp "$BINARY_PATH" "$INSTALL_BIN"
sudo chmod +x "$INSTALL_BIN"
sudo systemctl daemon-reload
sudo systemctl restart $UNIT_NAME
sudo systemctl status --no-pager $UNIT_NAME

echo "Redeployed $UNIT_NAME"
