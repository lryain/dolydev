#!/usr/bin/env bash
# 兼容 wrapper：调用统一的管理脚本执行 fix-unit（修复 systemd 单元）
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MANAGE_SCRIPT="$SCRIPT_DIR/manage_serial_service.sh"
if [ ! -x "$MANAGE_SCRIPT" ]; then
    echo "管理脚本不存在或不可执行: $MANAGE_SCRIPT" >&2
    exit 1
fi
exec "$MANAGE_SCRIPT" fix-unit