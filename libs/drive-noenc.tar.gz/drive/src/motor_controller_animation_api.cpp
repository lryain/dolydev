/**
 * @file motor_controller_animation_api.cpp
 * @brief 动画系统专用的电机控制 API 实现
 * 
 * 提供高级的距离移动和转向控制 API，支持：
 * - drive_distance: 支持加速度、刹车、方向控制
 * - drive_rotate: 支持原地转向和以轮为中心转向
 * 
 * Created: 2026-02-05
 

## 许可
GNU General Public License v3.0

## 作者
Kevin.Liu @ Make&Share
QQ: 47129927@qq.com

*/

#include "drive/motor_controller.hpp"
#include <iostream>
#include <cmath>
#include <thread>
#include <chrono>
#include <iomanip>

// ===== drive_distance: 高级距离移动 API =====

bool MotorController::drive_distance(float distance_mm, int speed, int accel, int brake, int direction, uint32_t timeout_ms) {
    // 参数验证
    if (speed < 0 || speed > 100) {
        std::cerr << "[drive_distance] ❌ 速度参数无效: " << speed << " (应在 0-100 之间)" << std::endl;
        return false;
    }
    if (direction != 0 && direction != 1) {
        std::cerr << "[drive_distance] ❌ 方向参数无效: " << direction << " (应为 0=前进 或 1=后退)" << std::endl;
        return false;
    }

    if (accel < 0 || accel > 100) {
        std::cerr << "[drive_distance] ❌ 加速度参数无效: " << accel << " (应在 0-100 之间)" << std::endl;
        return false;
    }
    if (brake < 0 || brake > 100) {
        std::cerr << "[drive_distance] ❌ 刹车参数无效: " << brake << " (应在 0-100 之间)" << std::endl;
        return false;
    }
   
    // 转换参数
    float distance_cm = distance_mm / 10.0f;  // mm -> cm
    if (direction == 1) {
        distance_cm = -distance_cm;  // 后退
    }
    float max_speed = speed / 100.0f;  // 百分比 -> [0, 1]

    if (!encoders_enabled || (!left_encoder || !right_encoder)) {
        std::cerr << "[drive_distance] ❌ 编码器未启用或未初始化" << std::endl;
        // 使用forward代替
        if (direction == 1) {
            backward(40, distance_cm*0.1);
        }else{
            forward(40, distance_cm*0.1);

        }
        return true;
    }

    float accel_factor = accel / 100.0f;
    float brake_factor = brake / 100.0f;

    std::cout << "\n[drive_distance] ====== 高级距离移动开始 ======" << std::endl;
    std::cout << "[drive_distance] 距离: " << distance_mm << " mm (" << distance_cm << " cm)" << std::endl;
    std::cout << "[drive_distance] 速度: " << speed << "% (" << max_speed << ")" << std::endl;
    std::cout << "[drive_distance] 加速度: " << accel << "% (" << accel_factor << ")" << std::endl;
    std::cout << "[drive_distance] 刹车: " << brake << "% (" << brake_factor << ")" << std::endl;
    std::cout << "[drive_distance] 方向: " << (direction == 0 ? "前进" : "后退") << std::endl;
    std::cout << "[drive_distance] 超时: " << timeout_ms << " ms" << std::endl;

    int32_t target_pulses = distance_to_pulses(distance_cm);
    int32_t tolerance = encoder_config_.position_tolerance;
    int32_t abs_target = std::abs(target_pulses);

    reset_encoders();
    std::this_thread::sleep_for(std::chrono::milliseconds(10));

    auto start_time = std::chrono::steady_clock::now();
    int32_t last_log_ms = 0;
    
    // 定义加速和减速阶段
    float accel_phase_percent = 0.0f;  // 加速阶段距离百分比
    float decel_phase_percent = 1.0f;  // 减速阶段开始的距离百分比
    
    if (accel > 0) {
        // 加速阶段占总距离的 accel% / 2（因为加速和减速对称）
        accel_phase_percent = accel_factor * 0.3f;  // 最多占 30%
    }
    
    if (brake > 0) {
        // 减速阶段在最后的 brake% 距离开始
        decel_phase_percent = 1.0f - (brake_factor * 0.3f);  // 最后 30%
    }

    while (true) {
        auto now = std::chrono::steady_clock::now();
        uint32_t elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(now - start_time).count();

        // 超时检查
        if (elapsed_ms > timeout_ms) {
            stop();
            std::cerr << "[drive_distance] ❌ 超时 (" << elapsed_ms << "ms > " << timeout_ms << "ms)" << std::endl;
            return false;
        }

        // 读取当前位置
        int32_t left_pos = getLeftEncoderPosition();
        int32_t right_pos = getRightEncoderPosition();
        int32_t avg_pos = (left_pos + right_pos) / 2;
        int32_t error = target_pulses - avg_pos;

        // 日志输出（200ms 一次）
        if (elapsed_ms - last_log_ms >= 200) {
            float progress = (abs_target > 0) ? (100.0f * std::abs(avg_pos) / abs_target) : 0.0f;
            std::cout << "[drive_distance] t=" << std::setw(4) << elapsed_ms << "ms | "
                      << "pos=" << std::setw(4) << avg_pos << "/" << target_pulses 
                      << " err=" << std::setw(4) << error 
                      << " | progress=" << std::setw(3) << static_cast<int>(progress) << "%" << std::endl;
            last_log_ms = elapsed_ms;
        }

        // 到达目标（容限内）
        if (std::abs(error) <= tolerance) {
            std::cout << "[drive_distance] ✅ 到达目标！最终位置=" << avg_pos 
                      << " 目标=" << target_pulses << " 误差=" << error << std::endl;
            
            // 刹车处理
            if (brake > 0) {
                std::cout << "[drive_distance] 🛑 执行刹车 (强度=" << brake << "%)" << std::endl;
                stop();
                std::this_thread::sleep_for(std::chrono::milliseconds(100 + brake));  // 刹车延时
            } else {
                stop();
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
            
            return true;
        }

        // 计算当前速度（根据进度调整）
        float progress_percent = (abs_target > 0) ? (static_cast<float>(std::abs(avg_pos)) / abs_target) : 0.0f;
        float throttle = max_speed;

        if (accel > 0 && progress_percent < accel_phase_percent) {
            // 加速阶段：从 10% 逐渐加速到 max_speed
            float accel_progress = progress_percent / accel_phase_percent;  // [0, 1]
            throttle = 0.1f + accel_progress * (max_speed - 0.1f);
        } else if (brake > 0 && progress_percent > decel_phase_percent) {
            // 减速阶段：从 max_speed 逐渐减速到 15%
            float decel_progress = (progress_percent - decel_phase_percent) / (1.0f - decel_phase_percent);  // [0, 1]
            throttle = max_speed - decel_progress * (max_speed - 0.15f);
        } else {
            // 巡航阶段：保持 max_speed
            throttle = max_speed;
        }

        // 执行移动
        if (error > 0) {
            forward(throttle);
        } else {
            backward(std::abs(throttle));
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

// ===== drive_distance_pid: 基于 PID 的高级距离移动 =====

bool MotorController::drive_distance_pid(float distance_mm, int speed, int accel, int brake, int direction, uint32_t timeout_ms) {
    // 参数验证
    if (speed < 0 || speed > 100) {
        std::cerr << "[drive_distance_pid] ❌ 速度参数无效: " << speed << std::endl;
        return false;
    }
    if (direction != 0 && direction != 1) {
        std::cerr << "[drive_distance_pid] ❌ 方向参数无效: " << direction << " (应为 0 或 1)" << std::endl;
        return false;
    }

    // 转换单位和符号：mm -> cm，方向 1 则为负
    float distance_cm = distance_mm / 10.0f;
    if (direction == 1) {
        distance_cm = -distance_cm;  // 后退为负
    }

    // 转换速度：百分比 0-100 -> 小数 0.0-1.0
    float max_speed = speed / 100.0f;

    // 调用标准 PID 移动函数
    std::cout << "[drive_distance_pid] 🔷 PID 精确距离移动: distance=" << distance_cm 
              << "cm, speed=" << speed << "%, max_speed=" << max_speed << std::endl;
    
    return move_distance_cm_pid(distance_cm, max_speed, timeout_ms);
}

// ===== turn_deg_pid_advanced: 基于 PID 的高级转向控制 =====

bool MotorController::turn_deg_pid_advanced(float angle_deg, int speed, bool is_center_turn, uint32_t timeout_ms) {
    // 参数验证
    if (speed < 0 || speed > 100) {
        std::cerr << "[turn_deg_pid_advanced] ❌ 速度参数无效: " << speed << std::endl;
        return false;
    }

    // 转换速度
    float max_speed = speed / 100.0f;

    std::cout << "[turn_deg_pid_advanced] 🔷 PID 精确转向: angle=" << angle_deg 
              << "°, speed=" << speed << "%, mode=" << (is_center_turn ? "CENTER" : "WHEEL") << std::endl;

    // 如果是以轮为中心的转向，需要做一个适配
    // PID 版本的 turn_deg_pid 假设是原地转向，所以这里做简单包装
    // 实际上，对于动画系统，最好直接使用 is_center_turn=true（原地转向）
    if (!is_center_turn) {
        // 为了支持轮轴心转向，这里做一个简单的算法适配
        // 轮轴心转向 = 一个轮子速度为 0，另一个轮子速度为 max_speed
        // 此时转向角度与原地转向不同：原地 180° = 轮轴心 360°
        // 进行简单的角度缩放（实际应该使用轮距和轴长精确计算）
        angle_deg = angle_deg * 2.0f;  // 粗略补偿
        std::cout << "[turn_deg_pid_advanced] ⚠️  轮轴心转向角度缩放: " << (angle_deg/2.0f) 
                  << "° -> " << angle_deg << "°" << std::endl;
    }

    return turn_deg_pid(angle_deg, max_speed, timeout_ms);
}

// ===== drive_rotate: 高级转向控制 API =====

bool MotorController::drive_rotate(float angle_deg, int speed, bool is_center_turn, uint32_t timeout_ms) {
    if (!encoders_enabled || (!left_encoder || !right_encoder)) {
        std::cerr << "[drive_rotate] ❌ 编码器未启用或未初始化" << std::endl;
        return false;
    }

    // 参数验证
    if (speed < 0 || speed > 100) {
        std::cerr << "[drive_rotate] ❌ 速度参数无效: " << speed << " (应在 0-100 之间)" << std::endl;
        return false;
    }

    float max_speed = speed / 100.0f;

    std::cout << "\n[drive_rotate] ====== 高级转向控制开始 ======" << std::endl;
    std::cout << "[drive_rotate] 角度: " << angle_deg << "° (" << (angle_deg > 0 ? "右转" : "左转") << ")" << std::endl;
    std::cout << "[drive_rotate] 速度: " << speed << "% (" << max_speed << ")" << std::endl;
    std::cout << "[drive_rotate] 模式: " << (is_center_turn ? "原地转向" : "以轮为中心转向") << std::endl;
    std::cout << "[drive_rotate] 超时: " << timeout_ms << " ms" << std::endl;

    int32_t target_pulse_diff;
    
    if (is_center_turn) {
        // 原地转向：两个轮子反向旋转
        target_pulse_diff = angle_to_pulse_diff(angle_deg);
    } else {
        // 以轮为中心转向：一个轮子不动，另一个轮子转动
        // 转向半径 = 轮距 (8cm)
        // 弧长 = 2 * π * 轮距 * (角度 / 360)
        float arc_length_cm = 2.0f * M_PI * encoder_config_.axle_width_cm * (std::abs(angle_deg) / 360.0f);
        int32_t arc_pulses = distance_to_pulses(arc_length_cm);
        
        // 对于以轮为中心的转向，目标脉冲差是弧长的两倍
        // （因为只有一个轮子在动，而编码器读取的是两轮的平均值）
        target_pulse_diff = (angle_deg > 0) ? arc_pulses * 2 : -arc_pulses * 2;
    }

    int32_t tolerance = encoder_config_.position_tolerance * 2;  // 转向容限稍大

    reset_encoders();
    std::this_thread::sleep_for(std::chrono::milliseconds(10));

    auto start_time = std::chrono::steady_clock::now();
    int32_t last_log_ms = 0;

    while (true) {
        auto now = std::chrono::steady_clock::now();
        uint32_t elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(now - start_time).count();

        // 超时检查
        if (elapsed_ms > timeout_ms) {
            stop();
            std::cerr << "[drive_rotate] ❌ 超时 (" << elapsed_ms << "ms > " << timeout_ms << "ms)" << std::endl;
            return false;
        }

        // 读取当前位置
        int32_t left_pos = getLeftEncoderPosition();
        int32_t right_pos = getRightEncoderPosition();
        int32_t pulse_diff = left_pos - right_pos;
        int32_t error = target_pulse_diff - pulse_diff;

        // 日志输出（200ms 一次）
        if (elapsed_ms - last_log_ms >= 200) {
            float progress = (std::abs(target_pulse_diff) > 0) ? 
                             (100.0f * std::abs(pulse_diff) / std::abs(target_pulse_diff)) : 0.0f;
            std::cout << "[drive_rotate] t=" << std::setw(4) << elapsed_ms << "ms | "
                      << "L=" << std::setw(4) << left_pos << " R=" << std::setw(4) << right_pos 
                      << " diff=" << std::setw(4) << pulse_diff << "/" << target_pulse_diff
                      << " | progress=" << std::setw(3) << static_cast<int>(progress) << "%" << std::endl;
            last_log_ms = elapsed_ms;
        }

        // 到达目标（容限内）
        if (std::abs(error) <= tolerance) {
            std::cout << "[drive_rotate] ✅ 到达目标！脉冲差=" << pulse_diff 
                      << " 目标=" << target_pulse_diff << " 误差=" << error << std::endl;
            stop();
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            return true;
        }

        // 执行转向
        if (is_center_turn) {
            // 原地转向：两轮反向
            if (angle_deg > 0) {
                // 右转：左轮前进，右轮后退
                setSpeeds(max_speed, -max_speed);
            } else {
                // 左转：左轮后退，右轮前进
                setSpeeds(-max_speed, max_speed);
            }
        } else {
            // 以轮为中心转向：一个轮子不动
            if (angle_deg > 0) {
                // 右转：右轮不动，左轮前进
                setSpeeds(max_speed, 0.0f);
            } else {
                // 左转：左轮不动，右轮前进
                setSpeeds(0.0f, max_speed);
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}
