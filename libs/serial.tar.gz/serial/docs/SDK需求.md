# SDK化

参考/home/pi/DOLY-DIY/SDK 每个模块的打包方式
1. 提供lib+include sdk 例如：include/ArmControl.h lib/libArmControl.so
2. 提供cpp cmake例子 例如：examples/cpp/ArmControl
3. 提供python binding 并提供python测试例子 例如：examples/python/ArmControl

我要将 libs/serial 模块以上述sdk化的形式发布出去，请提供自动化部署脚本，每次改动后，执行该脚本就可以发布该模块新的sdk版本到/home/pi/DOLY-DIY/SDK 下

## 需要注意的是
原来libs/serial 模块是以服务的方式运行，然后通过zmq协议来和其他模块通信，我现在需要将除服务和通信的部分外的核心部分分离出来并封装api然后打包成lib，这样直接通过api就可以操作libs/serial模块的api，而不需要服务运行！

要严格按照/home/pi/DOLY-DIY/SDK现有的范式和规范来sdk化模块！
完成后分别测试cpp和python例子

cpp的测试步骤：
1. cd到相应模块 例如：cd examples/cpp/ArmControl/build
cmake ..
3. 运行
LD_LIBRARY_PATH="/.doly/libs/opencv/lib:/home/pi/DOLY-DIY/SDK/lib:/usr/local/lib:$LD_LIBRARY_PATH" ./example

python的测试步骤：
1. cd到相应模块 例如：cd examples/python/ArmControl
2. 以可编辑的模式安装到 venv
source /home/pi/DOLY-DIY/venv/bin/activate
python3 -m pip install -e .
3. 执行python测试
LD_LIBRARY_PATH="/.doly/libs/opencv/lib:/home/pi/DOLY-DIY/SDK/lib:/usr/local/lib:$LD_LIBRARY_PATH" python example.py

