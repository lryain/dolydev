# Serial service

This module provides a serial listener service that reads bytes from a serial device
and publishes mapped events to the ZeroMQ bus.

Configuration
--------------
Place configuration in `config/serial.yaml`. Example:

```
device: /dev/serial0
baud: 115200
mappings:
  0x01: event.audio.cmd_turnon
  0x02: event.audio.cmd_turnoff
  0x03: event.audio.cmd_brightup
```

You can override the configuration file with command-line arguments:
- `--dev <device>`: set serial device
- `--baud <baud>`: set baud rate
- `--config <path>`: set alternative config file
- `--no-config`: ignore config file

Deployment
----------
Use the management script in `scripts/manage_serial_service.sh` to install and manage the systemd service. Examples:

```
cd libs/serial
./scripts/manage_serial_service.sh install
Use the `scripts/install_serial_service.sh` to install a systemd service and ensure it restarts automatically:

```
cd libs/serial
./scripts/install_serial_service.sh
```

Redeploy after changes:

```
cd libs/serial
./scripts/manage_serial_service.sh redeploy
./scripts/redeploy_serial_service.sh
```

Debugging & Testing
-------------------
- Use `scripts/manage_serial_service.sh status` to view the service status.
- Use `scripts/manage_serial_service.sh logs` to view the logs.
- For CI and local tests, you can use `tests/test_serial_publish.py` which will subscribe to the ZeroMQ bus and validate that messages are published.
